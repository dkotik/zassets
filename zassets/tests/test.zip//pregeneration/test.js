((g,h)=>{let i=function(){return this}(),e={},f=(c,d)=>{if(typeof c==="number"){let a=e[c],b;return a||(a=e[c]={exports:{}},g[c].call(i,f,a.exports,a)),b=a.exports,d&&(!b||!b.__esModule)&&((!b||typeof b!=="object")&&(b={}),"default"in b||Object.defineProperty(b,"default",{get:()=>a.exports,enumerable:!0})),b}d.__esModule=()=>!0;for(let a in d)Object.defineProperty(c,a,{get:d[a],enumerable:!0})};return f(h)})({1(){function a(){alert("testing exported symbol")}
alert("javascript"),a();
}},1);
