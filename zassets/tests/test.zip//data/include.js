
export function test2() {
  alert("testing exported symbol");
}
