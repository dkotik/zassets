import {test2} from "./include.js"

// Javascript test
alert('javascript');

test2();
